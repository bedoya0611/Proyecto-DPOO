package compradores;


public class Propietario extends Comprador{
	

	public Propietario(boolean verificacion, String nNombre, int identificacion, int nTelefono, String nLogin, String contraseña) {
		super(verificacion, nNombre, identificacion, nTelefono, nLogin, contraseña);
	}
	
}
